"""
AutoGrader
Anthony Bisgood
"""    

import subprocess
import os

def main():
    # use subprocess.Popen for this
    CFilePath = input("C source file path:\n")
    # use OS.listdir for this
    directoryPath = input('Test file directory path:\n')
    command = "gcc -Wall -Werror -std=c11 " + CFilePath + " -lm"
    toFindCommand = "find -name *txt"
    runCommand = "./a.out"
    try:
        # compiles code
        subprocess.call(command.split())
    except:
        print("failed to compile your code: ")
        exit()
    # these arrays are the relative paths of the test cases
    inputFiles = []
    outputFiles = []
    # goes into the directoryPath directory
    os.chdir(directoryPath)
    # finds all the input/output files
    fileLocations = subprocess.Popen(toFindCommand.strip().split(), stdout=subprocess.PIPE)
    for line in fileLocations.stdout:
        line = line.decode()
        line = line.strip("\n")
        if ("output.txt" in line):
            outputFiles.append(line)
        elif ("input.txt" in line):
            inputFiles.append(line)
    # goes through all the test cases   
    for i in range(len(inputFiles)):
        out = ""
        # opens input file
        file = open(inputFiles[i])
        while ("a.out" not in os.listdir()):
            # goes up a directory so we can call ./a.out
            os.chdir(os.path.dirname(os.getcwd()))  
        # puts the file data into tests.stdout
        tests = subprocess.Popen(runCommand.strip().split(), stdin=file, stdout=subprocess.PIPE)
        tests.wait()
        # out is the solution that we get from the program
        for line in tests.stdout.readlines():
            out += line.decode()
        # goes back into the test directoryPath directory
        os.chdir(directoryPath)
        isTheSame(out, outputFiles[i])
            
# returns true if they match, false otherwise
def isTheSame(out, outputFile):
    file = open(outputFile, 'r')
    real = ""
    for line in file.readlines():
        real += line
    directoryArray = outputFile.split("/")
    pos = directoryArray.index("output.txt")
    name = directoryArray[pos -1]
    if (out == real):
        print("#### Test: " + name + " passed! ####")
    else:
        print("#### Test: " + name + " failed! ####")
        print("#### EXPECTED TO SEE:")
        print(real.strip("\n"))
        print("#### INSTEAD GOT:")
        print(out.strip("\n"))
        
    
if __name__ == "__main__":
    main()
    

