#include <stdlib.h>
#include <stdio.h>
//Anthony Bigsood
//Lets the user find out how many different spots a piece could potentially be in
int brigadier(int moves);
int king(int moves);
int pawn(int moves);

int main() {
	char piece;
	int moves;
	printf("Enter piece type (k, b, p):\n");
	scanf("%c", &piece);
	printf("Enter number of moves:\n");
	scanf("%d", &moves);
	int res;
	if (piece == 'k'){
		res = king(moves);
	} else if (piece == 'b'){
 		res = brigadier(moves);
	} else if (piece == 'p'){
		res = pawn(moves);
	} else {
		printf("Enter a valid piece. \n");
	}
	printf("possible locations: %d \n", res);
	return 0;
}

int brigadier(int moves){
	int total = 0;
	for (int i = 1; i <=  moves + 1; i+=1){
		if (i == 1){
			total += 1;
		} else{
			total += 4*(i-1);
		}
	}
	return total;
}

int king(int moves) {
	int res = (2*moves + 1) * (2*moves + 1);
	return res;
}

int pawn(int moves) {
	int res = moves + 1;
	return res;
}

